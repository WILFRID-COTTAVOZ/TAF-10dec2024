#!/usr/bin/python3
#
# Christophe BLAESS 2020-2023.
#
# Licence MIT.
#
import socket
import sys
print("Python {} says 'Hello' from {}".format(sys.version[0:3],socket.gethostname()))
