#!/bin/sh
echo "Hello Fabien, I will load the azerty keyboard"
loadkeys /usr/bin/fr.keymap
: exit 0
